var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvw",
  1: "acfhlmnpqstuw",
  2: "chlmstu",
  3: "cfhilmprstuw",
  4: "_abcdefghiklmnopqrstuvw",
  5: "mp",
  6: "_amp",
  7: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Pages"
};

