var indexSectionsWithContent =
{
  0: "abcdehiklmnpqrstuvw",
  1: "m",
  2: "m",
  3: "m",
  4: "abcdehiklmnpqrstuvw",
  5: "mp",
  6: "m",
  7: "m",
  8: "m",
  9: "acmqst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

